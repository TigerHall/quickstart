+++
description = "Demonstration of an author."
title = "Author Demo"
[paige.author]
email = "example@example.com"
name = "Author Demo"
url = "https://example.com"
+++
