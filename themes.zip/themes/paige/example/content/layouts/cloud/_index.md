+++
authors = ["author-demo"]
categories = ["layouts", "paige"]
description = "Demonstration of the cloud layout."
layout = "paige/cloud"
tags = ["cloud"]
title = "Cloud"
+++

The `paige/cloud` layout displays list page links as a link cloud.

<!--more-->

This page has the following parameters:

```yaml
layout: "paige/cloud"
```

Result:
