+++
description = "Demonstration of a series."
title = "Series Demo"
+++
