+++
authors = ["author-demo"]
categories = ["content", "paige"]
description = "A front matter link."
link = "https://willfaught.com/paige"
tags = ["link"]
title = "Link"
+++

It takes you to the home page.
