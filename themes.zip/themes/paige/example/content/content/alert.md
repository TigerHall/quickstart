+++
authors = ["author-demo"]
categories = ["content", "paige"]
description = "An alert."
tags = ["alerts"]
title = "Alert"
[paige.alert]
message = "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
type = "primary"
+++

This page has the following parameters:

```yaml
paige:
  alert:
    message: "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
    type: "primary"
```
